const mongooes = require('mongoose');
const data101 = mongooes.Schema({
    id: {
        type: String,
        required: true,
    },
    character: {
        type: String,
        default: ""
    },
    backpack: {
        type: String,
        default: ""
    },
    pickaxe: {
        type: String,
        default: ""
    },
    glider: {
        type: String,
        default: ""
    },
    skydivecontrail: {
        type: String,
        default: ""
    },
    dance: {
        type: Array,
        default: [
            "",
            "",
            "",
            "",
            "",
            "",
        ]
    },
    itemwrap: {
        type: Array,
        default: [
            "",
            "",
            "",
            "",
            "",
            "",
            ""
        ]
    },
    musicpack: {
        type: String,
        default: ""
    },
    loadingscreen: {
        type: String,
        default: ""
    },
    profilerevision: {
        type: Number,
        default: 1
    },
    vbucks: {
        type: Number,
        default: 8000
    },
    level: {
        type: Number,
        default: 69
    }
})

module.exports = mongooes.model("Athena_Cosmetics", data101);
