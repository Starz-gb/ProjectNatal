const Athena_Cosmetics = require("../../model/Athena_Cosmetics")
module.exports = {
    async grabItems(accountID) {
        const AccountData = await Athena_Cosmetics.findOne({ id: accountID }).lean().catch(err => next(err));
        var AthenaNewData = {
            "Currency:MtxPurchased": {
                "attributes": {
                    "platform": "EpicPC"
                },
                "quantity": AccountData.vbucks,
                "templateId": "Currency:MtxGiveaway"
            },
        }
        return AthenaNewData
    },
    async attributes() {
        var AthenaNewData = {
            "mtx_affiliate": "ok",
            "current_mtx_platform": "EpicPC",
            "mtx_purchase_history": {

            }
        }
        return AthenaNewData
    }
}