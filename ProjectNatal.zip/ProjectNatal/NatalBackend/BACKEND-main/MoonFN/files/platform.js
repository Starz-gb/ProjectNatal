module.exports = (app, fs) => {
    app.all('/fortnite/api/game/v2/tryPlayOnPlatform/account/*', (req, res) => {
        res.setHeader('Content-Type', 'text/plain');
        res.send(true);
        res.end();
    })
}