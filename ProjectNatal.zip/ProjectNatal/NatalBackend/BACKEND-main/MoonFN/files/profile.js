const Athena_Cosmetics = require("../../model/Athena_Cosmetics")
const Athena_CommonCore = require("../AccountSettings/commoncore")


module.exports = (app, fs) => {
	app.all('/fortnite/api/game/v2/tryPlayOnPlatform/account/*', (req, res) => {
		res.setHeader('Content-Type', 'text/plain');
		res.send(true);
		res.end();
	})
	app.all(`/fortnite/api/game/v2/profile/:accountId/*/:command`, async (req, res) => {
		const command = req.params.command;
		const profileID = req.query.profileId;
		const accountId = req.params.accountId;
		const rvn = req.query.rvn;
		//try now? IDK

		try {
			var AccountData = await Athena_Cosmetics.findOne({ id: accountId }).lean().catch(err => next(err));
			console.log(AccountData)
			var AccountNewData = {
				"profileRevision": AccountData.profilerevision,
				"profileId": profileID,
				"profileChangesBaseRevision": AccountData.profilerevision,
				"profileChanges": [
					{
						"changeType": "fullProfileUpdate",
						"_id": "RANDOM",
						"profile": {
							"_id": "RANDOM",
							"Update": "",
							"Created": "2021-03-07T16:33:28.462Z",
							"updated": "2021-05-20T14:57:29.907Z",
							"rvn": 0,
							"wipeNumber": 1,
							"accountId": "",
							"profileId": profileID,
							"version": "no_version",
							"items": {},
							"stats": {
								"attributes": {}
							},
							"commandRevision": 5
						}
					}
				],
				"serverTime": new Date().toISOString(),
				"profileCommandRevision": AccountData.profilerevision,
				"responseVersion": 1
			}
			if (profileID == "athena") {
				return AccountNewData;
			}
			else if (profileID == "common_core" || "common_public") {
				AccountNewData['profileChanges'][0]['profile']['items'] = await Athena_CommonCore.grabItems(accountId)
				AccountNewData['profileChanges'][0]['profile']['stats']['attributes'] = await Athena_CommonCore.attributes()
				return AccountNewData;
			}else{
					var Json69 = {
				profileRevision: rvn + 1,
				profileId: profileID,
				profileChangesBaseRevision: 1,
				profileChanges: [],
				profileCommandRevision: 1,
				serverTime: new Date(),
				responseVersion: 1
			}//ah alr.
			return res.json(Json69)
			}
		
		} catch (err) {
			console.log(err)
			var Json69 = {
				profileRevision: rvn + 1,
				profileId: profileID,
				profileChangesBaseRevision: 1,
				profileChanges: [],
				profileCommandRevision: 1,
				serverTime: new Date(),
				responseVersion: 1
			}//goofy ahhh
			res.json(Json69)
		}
	})

	app.all(`/fortnite/api/game/v2/profile/:accountId/client/ClientQuestLogin`, async (req, res) => {
	})

	app.post("/fortnite/api/game/v2/profile/:accountId/client/SetMtxPlatform", (req, res) => {
	})

}