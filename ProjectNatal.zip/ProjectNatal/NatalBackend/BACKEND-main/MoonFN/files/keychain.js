const axios = require('axios');
module.exports = (app, fs) => {
    app.get('/fortnite/api/storefront/v2/keychain', async (req, res) => {
        axios.get("https://api.nitestats.com/v1/epic/keychain").then(response => {
            res.send(response.data);
            res.status(200);
        }).catch(function (error) {
            if (error.response) {
                res.sendFIle(path.join(__dirname, "../json/keychain.json"));
            }
        })
    })
}