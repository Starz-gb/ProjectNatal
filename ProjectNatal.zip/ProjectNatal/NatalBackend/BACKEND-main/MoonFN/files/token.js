const crypto = require("crypto")
const users = require('../../model/Athena_User')

module.exports = (app, fs) => {
	app.all("/account/api/oauth/token", async (req, res) => {
		if (req.method != "POST") {
			res.json({ "err": "Wrong Request" })
		}
		const grant_type = req.body.grant_type
		var displayName = "";
		var accountId = "";

		if (grant_type == "password") {
			try {
				var TEST1 = await users.findOne({ email: new RegExp(`^${req.body.username}$`, 'i') }).lean();
		var TEST2 = await users.findOne({ password: new RegExp(`^${req.body.password}$`, 'i') }).lean();
		if(TEST2 == null){
				return res.status(400).json(
						"errors.com.epicgames.common.oauth.invalid_client", 1011,
						"It appears that your Authorization header may be invalid or not present, please verify that you are sending the correct headers.",
						"com.epicgames.account.public", "prod", []
				)
		}

				 displayName = TEST2.displayName
				accountId = TEST2.id
				console.log(displayName)
		}catch (err) {
			 return res.status(400).json(
                    "errors.com.epicgames.common.oauth.invalid_client", 1011,
                    "It appears that your Authorization header may be invalid or not present, please verify that you are sending the correct headers.",
                    "com.epicgames.account.public", "prod", []
                )
		}
		}
		if (grant_type == "exchange_code") {
			displayName = req.body.exchange_code;
			accountId = req.body.exchange_code;
		}
		if (grant_type == "client_credentials") {
			displayName = undefined;
			accountId = undefined;
		}
		if (grant_type == "authorization_code" || grant_type == "device_auth") {
			// FrEe CoDe OmG
		}
		res.json({
			access_token: crypto.randomBytes(16).toString("hex"),
			expires_in: 28800,
			expires_at: "9999-12-31T23:59:59.999Z",
			token_type: "bearer",
			account_id: accountId,
			client_id: "ec684b8c687f479fadea3cb2ad83f5c6",
			internal_client: true,
			client_service: "fortnite",
			displayName: displayName,
			app: "fortnite",
			in_app_id: accountId,
			device_id: "5dcab5dbe86a7344b061ba57cdb33c4f"
		});
	})
}