const Athena_Users = require('../../model/Athena_User')


module.exports = (app, fs) => {
    app.get("/account/api/public/account/:accountId", async (req, res) => {
        console.log(req.params.accountId)

        var user = await Athena_Users.findOne({ id: req.params.accountId }).lean();

       if (user) res.json({
            "id": user.id,
            "displayName": user.displayName,
            "name": user.id,
            "email": user.email,
            "failedLoginAttempts": 0,
            "lastLogin": new Date().toISOString(),
            "numberOfDisplayNameChanges": 0,
            "ageGroup": "UNKNOWN",
            "headless": false,
            "country": "US",
            "lastName": "User",
            "preferredLanguage": "en",
            "canUpdateDisplayName": false,
            "tfaEnabled": false,
            "emailVerified": true,
            "minorVerified": false,
            "minorExpected": false,
            "minorStatus": "UNKNOWN"
        })
    })
    app.delete("/account/api/oauth/sessions/kill/*", async (req, res) => {
        res.status(204);
        res.end();
    });
    app.get("/account/api/public/account", async (req, res) => {
        var user = await Athena_Users.findOne({ id: req.params.accountId }).lean();
        if (user) res.json(
            [{
                "id": user.id,
                "displayName": user.displayName,
                "externalAuths": {}
            },]
        )
    })
    app.get("/account/api/public/account/displayName/:username", async (req, res) => {
        
        var user = await Athena_Users.findOne({ id: req.params.accountId }).lean();
        if (user) res.json(
            [{
                "id": user.id,
                "displayName": user.displayName,
                "externalAuths": {}
            },]
        )
    })
    app.all("/datarouter/api/v1/public/data", (req, res) => res.status(204).end())
    app.get("/fortnite/api/matchmaking/session/findPlayer/:id", (req, res) => {
            res.json([])
    })
}