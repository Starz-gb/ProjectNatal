module.exports = (app, fs) => {
    app.get("/fortnite/api/v2/versioncheck/*", (req, res) => {
        res.json({
            "type": "NO_UPDATE"
        })
    })
    app.get("/fortnite/api/v2/versioncheck/*", (req, res) => {
        res.json({
            "type": "NO_UPDATE"
        })
    })
    app.get("/fortnite/api/v2/versioncheck/*", (req, res) => {
        res.json({
            "type": "NO_UPDATE"
        })
    })
}