const Athena_Users =  require('../../model/Athena_User')

module.exports = (app, fs) => {
    app.get("/account/api/oauth/verify", async (req, res) => {
        var user = await Athena_Users.findOne({ id: req.params.accountId }).lean();
       if (user) res.json({
            "token": "Test123",
            "session_id": "3c3662bcb661d6de679c636744c66b62",
            "token_type": "bearer",
            "client_id": "Test123",
            "internal_client": true,
            "client_service": "fortnite",
            "account_id": "Argon",
            "expires_in": 28800,
            "expires_at": "9999-12-02T01:12:01.100Z",
            "auth_method": "exchange_code",
            "display_name": user.displayName,
            "app": "fortnite",
            "in_app_id": "Test123",
            "device_id": "Test123"
        })
    })
    app.get("/account/api/oauth/verify", (req, res) => {
        res.status(204).end()
    })
}