module.exports = (app, fs) => {
    app.get("/fortnite/api/game/v2/enabled_features", (req, res) => {
        console.log("GET: /fortnite/api/game/v2/enabled_features")
        res.json([])
    })
}