const axios = require('axios');
const express = require('express');
const app = express();
const bodyparser = require('body-parser');
const fs = require('fs');
const chalk = require('chalk');
const config = require('./config.json');
const mongoose = require('mongoose');

//Mongoose
mongoose.connect(config.mon.URl, { useNewUrlParser: true, useUnifiedTopology: true}, async e => {
    if (e) throw e
    console.log("MongoDB Connected");
})
//PORT
const PORT = config.Port

//fs
fs.readdir("./MoonFN/files/", (err, files) => {
    files.filter(function(Files) {
        if(!Files.endsWith(".js")){
            console.log(Files, ` ${SERVER} must end with .js`)
        }else{
            try{
                require(`./MoonFN/files/${Files}`)(app, fs)
                console.log(chalk.bold.green(Files))
            }catch(err){
                console.log("failed to load",Files, "-", err)
            }
        }
    })
})

fs.readdir("./profiles/", (err, files) => {
    files.filter(function(Files) {
        if(!Files.endsWith(".json")){
            console.log(Files, ` ${SERVER} must end with .js`)
        }else{
            try{
                require(`./profiles/${Files}`)
                console.log(chalk.bold.green(Files))
            }catch(err){
                console.log("failed to load",Files, "-", err)
            }
        }
    })
})

//express(app)
app.get('/', (req, res) => {
    res.send('Listening to Port: ' + config.Port)
})
app.listen(PORT, () => {
    console.log(chalk.bold.cyan("Listening port to ") + chalk.bold.yellow(PORT))
})
app.use((req, res, next) => {
    console.log(`req: ${req.url}`);
    next();
});
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({ extended: true }))